
/**
* @file enigme.h
*/

#include<string.h>
#include<stdio.h>
#include<stdlib.h>

/**
* @struct question
* @brief struct for question
*/
typedef struct Question {
	char question[255]; /*!<taille*/
	char reponse1[255]; /*!<taille*/
	char reponse2[255]; /*!<taille*/
	char reponse3[255]; /*!<taille*/
} Question;

/**
* @struct enigme
* @brief struct for enigme
*/
typedef struct enigme {
	FILE *f; /*!<fichier*/
	Question questions[5]; /*!<taille*/
} enigme;

void enigme_Init(enigme *q,char* filename);
const char* getQuestion(Question *t,int q);
void affichechoixalea();

