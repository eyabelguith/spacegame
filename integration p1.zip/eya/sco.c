#include "sco.h"
void afficher3(back* b)
{
        b->image = IMG_Load("back3.png");

        if(b->image == NULL) {
                printf("Unable to load Hero gif:%s\n", SDL_GetError());

        }
}
void initialiser3(back* b)
{ b->image=NULL;
  b->pos.x = 0;
    b->pos.y = 0;
b->pos.h=450;
b->pos.w=750;
}
void display(back b,SDL_Surface* screen)
{

SDL_BlitSurface(b.image,&b.pos,screen, NULL);
}
void freeback(back* b)
{
SDL_FreeSurface(b->image);
}
void scorlling(back* b,SDL_Event event)
{ 
 switch(event.type)
        {
case SDL_KEYDOWN: 
   switch(event.key.keysym.sym)

        {

            case SDLK_RIGHT: // Flèche droite
                b->pos.x+=10;//50

break;
case SDLK_LEFT:
b->pos.x-=10;
 break;
}
break;
}
}

