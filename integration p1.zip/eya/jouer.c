#include "jouer.h"
#include <time.h>
int collision(SDL_Rect a, SDL_Rect b){
	if(!(a.x > b.x+b.w || a.y > b.y+b.h || a.x+a.w < b.x || a.y+a.h < b.y)){
	return 1;
}
	return 0;
}
void resolution(SDL_Surface* screen) {
	int running = 1;
int rep;
	int currentChoice = 0;

srand(time(NULL));
int qid = (int)(random()%5); //  num question a afficher aléatoirement
int choices[3] = {0,1,2}; // il y a 3 choix possibles 


affichechoixalea();
	enigme q;

	enigme_Init(&q,"questions.txt"); // appel fonction pour initialiser les questions et les reps  

	SDL_Surface *msg, *ind; // msj c'est le message affiché selon le choix et ind c'est l'indice devant les réponses le petit rectangle

// initialisation
	TTF_Font *font = NULL;
	SDL_Init(SDL_INIT_EVERYTHING);
	TTF_Init();
	//screen = SDL_SetVideoMode(1200,600,32,SDL_HWSURFACE| SDL_INIT_TIMER);
        //SDL_WM_SetCaption("Enigme statique",NULL);//titre de la fenetre





	SDL_Event event;

	font = TTF_OpenFont("font.ttf", 26);

	SDL_Color color = {255,255,255};

	SDL_Rect rect;
	SDL_Rect choice;
// coordonnes ind l indice le ptit rectangle
	choice.x = 150;
	choice.y = 250;

	ind = SDL_CreateRGBSurface(0,16,16,32,0,0,0,0); // creation du petit rectanle comme indice avant les reponses 
	SDL_FillRect(ind,NULL,SDL_MapRGB(ind->format,255,0,0));// couleur du rectangle avamt les reponses
	SDL_EnableKeyRepeat(0,0);


// code de la résolution 

	while(running) {
		while(SDL_PollEvent(&event)){
			if(event.type == SDL_QUIT){
					running = 0;
			}
			if(event.type == SDL_KEYDOWN){
				if(event.key.keysym.sym == SDLK_ESCAPE){
					running = 0;
				}
				if(event.key.keysym.sym == SDLK_DOWN){
					if(currentChoice != 2)
						currentChoice++;
					else 
						currentChoice = 0;	
				}
				if(event.key.keysym.sym == SDLK_UP){
					if(currentChoice != 0)
						currentChoice--;
					else 
						currentChoice = 2;	// boucle pour le rectangle ( pour qu'il soit tjrs juste devant les choix )
				}
				if(event.key.keysym.sym == SDLK_RETURN){


					if(choices[currentChoice] == 0){ // choix correct 
						running = 0;
						SDL_Rect t;
						t.x = 300;  // coordonnes du message a afficher 
						t.y = 400;
						msg = TTF_RenderText_Solid(font, "Correct Answer" , color);
						SDL_BlitSurface(msg,NULL,screen,&t);


						SDL_Flip(screen);
						SDL_Delay(1000);
					}
					else { // choix non correct
						running = 0;
						SDL_Rect t;
						t.x = 300;
						t.y = 400;
						msg = TTF_RenderText_Solid(font, "Incorrect Answer" , color);
						SDL_BlitSurface(msg,NULL,screen,&t);
						SDL_Flip(screen);
						SDL_Delay(1000);




					}
				}
			}
		}

	SDL_FillRect(screen,&screen->clip_rect,0x007F7F7F); // couleur du fond 
	// coordones de la question a afficher 

	rect.x = 200;
	rect.y = 0;

	msg = TTF_RenderText_Solid(font, q.questions[qid].question , color); //font message du résultat  
	SDL_BlitSurface(msg,NULL,screen,&rect);



	/* blit des réponses chaque question

 ( appel fonction getquestion mais l indice est qid  car la question est posée aléatoirement) */

	rect.y = 50+50*0; //  l ordonné de la réponse 1
	msg = TTF_RenderText_Solid(font, getQuestion(&q.questions[qid],choices[0]) , color);// ecrire la réponse 1 sous forme texte
	SDL_BlitSurface(msg,NULL,screen,&rect);// blit réponse 1


	rect.y = 50+50*1;//l ordonné de la la réponse 2
	msg = TTF_RenderText_Solid(font, getQuestion(&q.questions[qid],choices[1]) , color);// ecrire la réponse 2 sous forme texte
	SDL_BlitSurface(msg,NULL,screen,&rect);// blit réponse 2


	rect.y = 50+50*2;// l ordonné de la la réponse 3
	msg = TTF_RenderText_Solid(font, getQuestion(&q.questions[qid],choices[2]), color);// ecrire la réponse 3 sous forme texte
	SDL_BlitSurface(msg,NULL,screen,&rect);// blit réponse 3


	choice.y = 50+currentChoice*50; //(  le petit rectangle se place avant la réponse ordonné du petit rectangle





SDL_Rect m;
m.x = 500;  // coordonnes du message de temps a afficher
m.y = 500;
msg = TTF_RenderText_Solid(font, "YOU ONLY HAVE 10 SECONDS TO ANSWER!" , color);// ecrire message sous forme texte
SDL_BlitSurface(msg,NULL,screen,&m); // blit message du temps


	SDL_BlitSurface(ind,NULL,screen,&choice); // blit du petit rectangle l indice devant les réponses
	SDL_Flip(screen);
	SDL_Delay(16);
	}

jouer(screen);
	SDL_FreeSurface(screen);
	SDL_FreeSurface(msg);
	TTF_CloseFont(font);
	TTF_Quit();
	SDL_Quit();
}


void jouer(SDL_Surface * screen)
{TTF_Init();
TTF_Font *police=NULL;
int continuer=1;
Time t2;
int i,j,a;
SDL_Event event;
Hero h;
text t;
ennemi e;
back b ;
int val;
srand(time(NULL));
val = rand()%2;
 initializerTemps(&t2);
initialiser3(&b);
afficher3(&b);
int posMax=600;
int posMin=500;
	 initialiser(&h,&t);
telecharger(&h,&t);
	 initialiser2(&e);
afficher2(&e);
SDL_EnableKeyRepeat(SDL_DEFAULT_REPEAT_DELAY,SDL_DEFAULT_REPEAT_INTERVAL);
while(continuer)
	{
SDL_PollEvent(&event);
switch(event.type)
        {
            case SDL_QUIT:
 continuer = 0;
                break;
        }
SDL_FillRect(screen, NULL, 0);
display(b,screen);
scorlling(&b,event);
animateHero(&h, event);
moveHero(&h,event,screen);
update_txt(&t,&h);
afficher_hero(h,screen);
afficher_vie(h,screen);
afficher_txt(t,screen);
afficher2(&e);
bliter(e,screen);
deplacer(&e,posMax,posMin);


SDL_UpdateRect(screen, 0, 0, 0, 0);
afficherTemps(&t2,&screen);
a=collision(h.positionAbsolue, e.pos);
if(a==1)
{   if (val==1)

 {resolution(screen);
}
 else
{
   if (enigme2(screen,police) == 1)
        {
    h.score+=20;

        }
else
{ h.nbvie-=1;
}
}
}
SDL_Flip(screen);
}
freeback(&b);
freeHero(&h,&t);
freenemi(&e);
TTF_CloseFont(police);
TTF_Quit();
SDL_Quit();
}
