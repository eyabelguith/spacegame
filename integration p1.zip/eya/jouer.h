#ifndef JOUER_H_
#define JOUEUR_H_
#include "ennemi.h"
#include "joueur.h"
#include"sco.h"
#include"time.h"
#include "enigme.h"
#include "aleatoire.h"
int collision(SDL_Rect a, SDL_Rect b);
void jouer(SDL_Surface* screen);
void resolution(SDL_Surface* screen);
#endif
