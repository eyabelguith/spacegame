#ifndef ENNEMI_H
#define ENNEMI_H
#include </usr/include/SDL/SDL.h>
#include </usr/include/SDL/SDL_image.h>
#include </usr/include/SDL/SDL_mixer.h>
#include"sco.h"

typedef struct
{
  SDL_Surface* image;
SDL_Surface* image2;
SDL_Rect pos ;
int direction;
}ennemi;
void afficher2(ennemi* e);
void bliter(ennemi e,SDL_Surface* screen);
void initialiser2(ennemi* e);
void deplacer(ennemi* e,int posMax,int posMin);
//void main2 ( int argc, char** argv );
void freenemi(ennemi* e);
#endif
