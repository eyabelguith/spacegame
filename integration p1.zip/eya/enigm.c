
/**
* @file main.c
* @brief Testing Program.
* @author C Team
* @version 0.1
* @date Apr 23, 2019
*
* Testing program for enigme
*
*/





#include<SDL/SDL.h>
#include<SDL/SDL_ttf.h>
#include<SDL/SDL_image.h>
#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include"enigme.h"




int main() {
	
	

	int running = 1;

	int currentChoice = 0;

srand(time(NULL));
int qid = (int)(random()%5); //  num question a afficher aléatoirement

	int choices[3] = {0,1,2}; // il y a 3 choix possibles 


affichechoixalea();

	// afficher les réponses chaque d'un ordre aléatoire
        /*for(int i = 0; i<10; i++){
		int t = random()%3;
		int t2 = random()%3;
		int t3 = choices[t];
		choices[t] = choices[t2];
		choices[t2] = t3;
	}*/

	// printf("%d %d %d\n",choices[0],choices[1],choices[2]);

// je l'ai fait dans une fonction affichechoixalea 


	
	enigme q;

	enigme_Init(&q,"questions.txt"); // appel fonction pour initialiser les questions et les reps  

	SDL_Surface *screen , *msg, *ind; // msj c'est le message affiché selon le choix et ind c'est l'indice devant les réponses le petit rectangle

// initialisation
	TTF_Font *font = NULL;
	SDL_Init(SDL_INIT_EVERYTHING);
	TTF_Init();
	screen = SDL_SetVideoMode(1200,600,32,SDL_HWSURFACE| SDL_INIT_TIMER);
        SDL_WM_SetCaption("Enigme statique",NULL);//titre de la fenetre





	SDL_Event event;

	font = TTF_OpenFont("font.ttf", 26);

	SDL_Color color = {255,255,255};

	SDL_Rect rect;
	SDL_Rect choice;
// coordonnes ind l indice le ptit rectangle
	choice.x = 150; 
	choice.y = 250;

	ind = SDL_CreateRGBSurface(0,16,16,32,0,0,0,0); // creation du petit rectanle comme indice avant les reponses 
	SDL_FillRect(ind,NULL,SDL_MapRGB(ind->format,255,0,0));// couleur du rectangle avamt les reponses
	SDL_EnableKeyRepeat(0,0);
	
// code timer 
Uint32 delay = (33 / 10000) * 10000; /* To round it down to 10 SECONDS */
SDL_TimerID timer; /* Variable pour stocker le numéro du timer */
SDL_TimerID SDL_AddTimer(Uint32 interval, SDL_NewTimerCallback callback, void *param);// Pour ajouter un timer
timer = SDL_AddTimer(10000,main,choices[currentChoice]); /* Démarrage du timer */
// code de la résolution 

	while(running) {
		while(SDL_PollEvent(&event)){
			if(event.type == SDL_QUIT){
					running = 0;
			}
			if(event.type == SDL_KEYDOWN){
				if(event.key.keysym.sym == SDLK_ESCAPE){
					running = 0;
				}
				if(event.key.keysym.sym == SDLK_DOWN){
					if(currentChoice != 2)
						currentChoice++;
					else 
						currentChoice = 0;	
				}
				if(event.key.keysym.sym == SDLK_UP){
					if(currentChoice != 0)
						currentChoice--;
					else 
						currentChoice = 2;	// boucle pour le rectangle ( pour qu'il soit tjrs juste devant les choix )
				}
				if(event.key.keysym.sym == SDLK_RETURN){


					if(choices[currentChoice] == 0){ // choix correct 
						running = 0;
						SDL_Rect t;
						t.x = 300;  // coordonnes du message a afficher 
						t.y = 400;
						msg = TTF_RenderText_Solid(font, "Correct Answer" , color);
						SDL_BlitSurface(msg,NULL,screen,&t);
						SDL_Flip(screen);
						SDL_Delay(1000);
					}
					else { // choix non correct
						running = 0;
						SDL_Rect t;
						t.x = 300;
						t.y = 400;
						msg = TTF_RenderText_Solid(font, "Incorrect Answer" , color);
						SDL_BlitSurface(msg,NULL,screen,&t);
						SDL_Flip(screen);
						SDL_Delay(1000);




					}
				}
			}
		}

	SDL_FillRect(screen,&screen->clip_rect,0x007F7F7F); // couleur du fond 
	// coordones de la question a afficher 
		
	rect.x = 200;
	rect.y = 0;

	msg = TTF_RenderText_Solid(font, q.questions[qid].question , color); //font message du résultat  
	SDL_BlitSurface(msg,NULL,screen,&rect);



	/* blit des réponses chaque question

 ( appel fonction getquestion mais l indice est qid  car la question est posée aléatoirement) */
	
	rect.y = 50+50*0; //  l ordonné de la réponse 1
	msg = TTF_RenderText_Solid(font, getQuestion(&q.questions[qid],choices[0]) , color);// ecrire la réponse 1 sous forme texte
	SDL_BlitSurface(msg,NULL,screen,&rect);// blit réponse 1

	
	rect.y = 50+50*1;//l ordonné de la la réponse 2
	msg = TTF_RenderText_Solid(font, getQuestion(&q.questions[qid],choices[1]) , color);// ecrire la réponse 2 sous forme texte
	SDL_BlitSurface(msg,NULL,screen,&rect);// blit réponse 2


	rect.y = 50+50*2;// l ordonné de la la réponse 3
	msg = TTF_RenderText_Solid(font, getQuestion(&q.questions[qid],choices[2]), color);// ecrire la réponse 3 sous forme texte
	SDL_BlitSurface(msg,NULL,screen,&rect);// blit réponse 3


	choice.y = 50+currentChoice*50; //(  le petit rectangle se place avant la réponse ordonné du petit rectangle


	


SDL_Rect m;
m.x = 500;  // coordonnes du message de temps a afficher 
m.y = 500;						
msg = TTF_RenderText_Solid(font, "YOU ONLY HAVE 10 SECONDS TO ANSWER!" , color);// ecrire message sous forme texte
SDL_BlitSurface(msg,NULL,screen,&m); // blit message du temps


	SDL_BlitSurface(ind,NULL,screen,&choice); // blit du petit rectangle l indice devant les réponses
	SDL_Flip(screen);
	SDL_Delay(16);
	}


	SDL_FreeSurface(screen);
	SDL_FreeSurface(msg);
	TTF_CloseFont(font);
        SDL_RemoveTimer(timer);
	TTF_Quit();
	SDL_Quit();

}

