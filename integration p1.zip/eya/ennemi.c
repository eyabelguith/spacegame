#include "ennemi.h"
void afficher2(ennemi* e)
{
        e->image = IMG_Load("ennemi.png");

 e->image2 = IMG_Load("ennemi2.png");
}

void bliter(ennemi e,SDL_Surface* screen)

{
if(e.direction==1)
 SDL_BlitSurface(e.image, NULL,  screen, &e.pos);
if(e.direction==0)
SDL_BlitSurface(e.image2, NULL,  screen, &e.pos);

}
void initialiser2(ennemi* e)
{
e->image=NULL;
e->image2=NULL;
e->pos.x=700;
e->pos.y=200;
e->direction=1;
}
void deplacer(ennemi *e,int posMax,int posMin)
{
if(e->pos.x>posMax)
e->direction=1;
if(e->pos.x<posMin)
e->direction=0;
if(e->direction==0)
e->pos.x+=1;//20
else
e->pos.x-=1;
}
void freenemi(ennemi* e)
{
        SDL_FreeSurface(e->image);
SDL_FreeSurface(e->image2);
}
/*void main2( int argc, char** argv )
{ ennemi e;
back b;
int posMax=600;
int posMin=0;
SDL_Surface* screen=NULL;
SDL_Event event;
int continuer = 1;
SDL_Init(SDL_INIT_VIDEO);
SDL_WM_SetCaption("ennemi", NULL);
 screen = SDL_SetVideoMode(750,450, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
initialiser2(&e);
SDL_EnableKeyRepeat(SDL_DEFAULT_REPEAT_DELAY,SDL_DEFAULT_REPEAT_INTERVAL);
while(continuer)
        {
SDL_PollEvent(&event);
        switch(event.type)
        {
            case SDL_QUIT:
             continuer = 0;
                break;
        }
 SDL_FillRect(screen, NULL, 0);
afficher2(&e);
bliter(e,b.image);
deplacer(&e,posMax,posMin);
SDL_UpdateRect(screen, 0, 0, 0, 0);
SDL_Flip(screen);
SDL_Delay(300);
}
freenemi(&e);
SDL_Quit();
}
*/
