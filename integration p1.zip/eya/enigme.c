
/**
* @file enigme.c
*/
#include"enigme.h"


void enigme_Init(enigme *q, char* filename) {


	q->f = fopen(filename,"r");


	for(int i = 0; i<5; i++){


		char buf[255]; // buffer pour stockage 


		fgets(buf, sizeof(buf),q->f);
		strcpy(q->questions[i].question,buf);

		fgets(buf, sizeof(buf),q->f);
		strcpy(q->questions[i].reponse1,buf);

		fgets(buf, sizeof(buf),q->f);
		strcpy(q->questions[i].reponse2,buf);

		fgets(buf, sizeof(buf),q->f);
		strcpy(q->questions[i].reponse3,buf);
	}

	fclose(q->f);
}


// fonction pour récupérer les réponses du fichier texte selon q 
/**
* @brief To initialize the questions .
* @param q the question
* @param filename the file which contains questions
* @return Nothing
*/

const char* getQuestion(Question *t,int q){
	if(q==0)
		return t->reponse1;
	if(q==1)
		{return t->reponse2;}


	return t->reponse3;
}

/**
* @brief To get question .
* @param t question
* @param q row of answers
* @return Nothing
*/


void affichechoixalea(){
int i,t,t2,t3;
int choices[3];

 for(int i = 0; i<10; i++){
		int t = random()%3;
		int t2 = random()%3;
		int t3 = choices[t];
		choices[t] = choices[t2];
		choices[t2] = t3;
	}




}
/**
* @brief To show randomly questions .
* @return Nothing
*/














