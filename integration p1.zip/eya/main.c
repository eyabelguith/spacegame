#include "jouer.h"

void main ( int argc, char** argv )
{

	SDL_Surface *screen=NULL;
	if ( SDL_Init( SDL_INIT_VIDEO ) < 0 ) 
	{
		printf( "Unable to init SDL: %s\n", SDL_GetError() );

	}
screen = SDL_SetVideoMode(750,450, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
		if ( !screen )
	{
		printf("Unable to set %d * %d video: %s\n",SCREEN_W, SCREEN_H, SDL_GetError());

	}


	jouer(screen);
//        SDL_Delay(1000);
SDL_Quit();
}
