#include "joueur.h"
void initialiser(Hero* H,text* txt)
{
        int i, j;
        H->positionAbsolue.x = 0;
        H->positionAbsolue.y = 200;
        H->positionAbsolue.w = Hero_WIDTH;
        H->positionAbsolue.h = Hero_HEIGHT;
        H->Frame.i = 0;
        H->Frame.j = 0;
        for (i = 0; i < 4; i++)
        {       for(j = 0; j < 4; j++)
                {
                        H->positionAnimation[i][j].x = j * Hero_WIDTH;
                        H->positionAnimation[i][j].y = i * Hero_HEIGHT;
                        H->positionAnimation[i][j].w = Hero_WIDTH;
                        H->positionAnimation[i][j].h = Hero_HEIGHT;
                }
        }
        H->nbvie = 3;
        H->score= 0;
        H->posvie.x=400;
        H->posvie.y=-110;
        txt->positionText.x = 490;
        txt->positionText.y = 15;
        txt->couleur.r=255;
        txt->couleur.g=255;
        txt->couleur.b=255;

}
void telecharger(Hero * H,text *txt)
{
        H->image = IMG_Load("t1.png");

        if(H->image == NULL) {
                printf("Unable to load Hero gif:%s\n", SDL_GetError());

        }
         H->vie=IMG_Load("vie1.png");
       H->vie2=IMG_Load("vie2.png");
     H->vie3=IMG_Load("vie3.png");
     H->vie4=IMG_Load("vie4.png");
        txt->police = TTF_OpenFont("arial.ttf", 40);


}
void afficher_hero(Hero H, SDL_Surface* screen)
{
 SDL_BlitSurface(H.image, &H.positionAnimation[H.Frame.i][H.Frame.j],  screen, &H.positionAbsolue);

 }
void afficher_vie(Hero H,SDL_Surface* screen)
{switch(H.nbvie)
{
case 1:
SDL_BlitSurface(H.vie3, NULL, screen, &H.posvie); break;
case 2:
SDL_BlitSurface(H.vie2, NULL, screen, &H.posvie); break;
case 3:
SDL_BlitSurface(H.vie, NULL, screen, &H.posvie); break;
case 4:
SDL_BlitSurface(H.vie4, NULL, screen, &H.posvie); break;
}
}
void update_txt(text* txt, Hero* H)
{
        sprintf(txt->t," Score = %d ",H->score);
}


void afficher_txt(text txt,SDL_Surface* screen)
{
txt.texte = TTF_RenderText_Blended(txt.police,txt.t,txt.couleur);
        SDL_SetColorKey(txt.texte, SDL_SRCCOLORKEY, SDL_MapRGB(txt.texte->format, 255, 255, 255));

        SDL_BlitSurface(txt.texte,NULL,screen,&(txt.positionText));
}


void moveHero(Hero *H, SDL_Event event,SDL_Surface* screen)
{

switch(event.type)
{
        case SDL_KEYDOWN:
        switch(event.key.keysym.sym)
        {
              case SDLK_RIGHT: // Flèche droite
H->positionAbsolue.x +=2;//20
                       break;
            case SDLK_LEFT: // Flèche gauche
H->positionAbsolue.x -=2;//20
                     break;
}
break;
//SDL_Delay(10);
}
}
void animateHero(Hero *H,SDL_Event event)
{
switch(event.type)
{
    case SDL_KEYDOWN:
        switch(event.key.keysym.sym)
        {
              case SDLK_RIGHT: // Flèche droite
                        H->Frame.i = 2;
                        H->Frame.j ++;
                        if (H->Frame.j == 4)
                                H->Frame.j = 0;
                       break;
 case SDLK_LEFT: // Flèche gauche
                        H->Frame.i = 1;
                        H->Frame.j ++;
                        if (H->Frame.j == 4)
                                H->Frame.j = 0;
                        break;
        }
        break;
}

}



void freeHero(Hero *H,text* txt)
{
        SDL_FreeSurface(H->image);
        SDL_FreeSurface(H->vie);
        SDL_FreeSurface(txt->texte);

}
/*void main1 ( int argc, char** argv )
{
Hero h;
text t;
SDL_Surface* screen ;
 SDL_Event event;
        int continuer = 1;
SDL_Init(SDL_INIT_VIDEO);
TTF_Init();

  SDL_WM_SetCaption("joueur", NULL);

   screen = SDL_SetVideoMode(750,450, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
initialiser(&h,&t);
afficher(&h,&t);
SDL_EnableKeyRepeat(SDL_DEFAULT_REPEAT_DELAY,SDL_DEFAULT_REPEAT_INTERVAL);//bch inajem yejry 
while(continuer)
        {
SDL_WaitEvent(&event);
        switch(event.type)
        {
            case SDL_QUIT:
 continuer = 0;
                break;
        }
 SDL_FillRect(screen, NULL, 0);//fasakh etsawer li saretelhom el animation
animateHero(&h, event);
moveHero(&h,event,screen);
update_txt(&t,&h);
display_hero(h,screen,t);
SDL_UpdateRect(screen, 0, 0, 0, 0);
if ( h.positionAbsolue.x < 0 ) {
      h.positionAbsolue.x = 0;
    }
    else if ( h.positionAbsolue.x > SCREEN_W-Hero_WIDTH) {
      h.positionAbsolue.x = SCREEN_W-Hero_WIDTH;
    }
    if ( h.positionAbsolue.y < 0 ) {
      h.positionAbsolue.y= 0;
    }
    else if ( h.positionAbsolue.y > SCREEN_H-Hero_HEIGHT ) {
      h.positionAbsolue.y = SCREEN_H-Hero_HEIGHT;
    }

                SDL_Flip(screen);

        }

freeHero(&h,&t);
TTF_Quit();
SDL_Quit();
}


*/

