
#ifndef SCO_H_
#define SCO_H_
#include </usr/include/SDL/SDL.h>
#include </usr/include/SDL/SDL_image.h>

typedef struct
{
SDL_Surface *image;

    SDL_Rect pos;


}back;
void initialiser3(back* b);
void afficher3(back* b);
void display(back b,SDL_Surface* screen);
void freeback(back* b);
void scorlling(back* b,SDL_Event event);
#endif
